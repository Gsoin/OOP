package connectfour;

import static connectfour.Board.readFrom;
import static connectfour.Board.RED;

import static connectfour.Board.YELLOW;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

public class BoardTest {

    @Test public void gameTest() throws IOException {
        Board game = new Board();
        for (int x = 3; x < 3 + 3; x++) {
            assertEquals(game.getPlayer(), RED);
            assertEquals(game.dropChip(x), 0);
            assertFalse(game.isWinning(x, 0));
            assertEquals(game.otherPlayer(), RED);
            assertEquals(game.getPlayer(), YELLOW);
            assertEquals(game.dropChip(x), 1);
            assertFalse(game.isWinning(x, 1));
        }
        assertEquals(game.getPlayer(), RED);
        assertEquals(game.dropChip(6), 0);
        assertTrue(game.isWinning(6, 0));
        assertEquals(game.otherPlayer(), RED);
        StringWriter sink = new StringWriter();
        game.writeBoardTo(sink);
/* 
        String finalBoard = """
                0,0,0,0,0,0,0
                0,0,0,0,0,0,0
                0,0,0,0,0,0,0
                0,0,0,0,0,0,0
                0,0,0,2,2,2,0
                0,0,0,1,1,1,1""";

        assertEquals(sink.toString(), finalBoard);
    }

    @Test public void loadSaveTest() throws IOException {
        String testBoardStr = """
                0,0,0,0,0,0,0
                0,0,0,0,0,0,0
                0,0,0,1,0,0,0
                0,0,0,1,1,0,0
                0,0,0,2,2,0,0
                0,0,0,1,2,0,0""";

                
        // Should not throw exceptions
        Board board = readFrom(new StringReader(testBoardStr));

        StringWriter sink = new StringWriter();
        board.writeBoardTo(sink);

        // The saved board must be equal to the initial one
        assertEquals(sink.toString(), testBoardStr);
        */
    }
    

    @Test public void badSaveTest() {
        assertThrows("Invalid chip format", IllegalStateException.class, () -> readFrom(new StringReader("too long,")));
        assertThrows("Unknown chip", IllegalStateException.class, 
        () -> readFrom(new StringReader("3, outside of the valid 0 1 2 range")));
        assertEquals(Board.WIDTH, 7);
        assertThrows("Too many columns", IllegalStateException.class,
        () -> readFrom(new StringReader("0,0,0,0,0,0,0, 8th column will crash it")));
        assertEquals(Board.HEIGHT, 6);
        /*
        assertThrows("Too many rows", IllegalStateException.class, () -> readFrom(new StringReader(
                """
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        7th row will crash it"""
        )));
        // More yellow chips than red chips = Illegal
        assertThrows("Too much chips of one color", IllegalStateException.class, () -> readFrom(new StringReader(
                """
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,2"""
        )));
        
        // Two more red chips than yellow chips = Illegal
        assertThrows("Too much chips of one color", IllegalStateException.class, () -> readFrom(new StringReader(
                """
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,0,0,0,0
                        0,0,0,1,1,1,2"""
        )));*/
    }
}