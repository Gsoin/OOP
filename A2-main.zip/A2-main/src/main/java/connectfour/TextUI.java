package connectfour;

import java.io.IOException;
import java.util.Scanner;

import static connectfour.Board.WIDTH;

/**
 * TextUI class that handles the displaying and input
 * 
 * @Gunteshwar Soin
 */
public class TextUI {
    private static final Scanner INPUT = new Scanner(System.in);

    /**
     * Helper method to start or load a game
     * 
     * @return game Board
     */
    public static Board askStartGame() {
        System.out.println(WELCOME_MSG);

        switch (INPUT.nextLine().trim().toLowerCase()) {
            case "load":
                System.out.print("Enter the filename: ");
                try {
                    return Board.loadBoard(INPUT.nextLine());
                } catch (IOException e) {
                    System.out.println("The file could not be found or is corrupted!");
                    System.out.println("An empty board will be used instead.");
                    // Will use the fallthrough mechanic
                }

            case "play":
                return new Board();
            default:
                System.out.println("Goodbye");
                

        }
        return null;
    }

    /**
     * Asks the player in which column do they want to drop a chip, or save the game
     * 
     * @param game Board to save if relevant
     * @return Selected column to drop a chip in
     */
    public static int askColumnOrSave(Board game) {
        while (true) {
            System.out.printf(TAKE_TURN_MSG, game.getPlayer(), WIDTH);
            if (INPUT.hasNextInt()) {
                int column = INPUT.nextInt() - 1;
                if (0 <= column && column < WIDTH) {
                    return column;
                }
            } else {
                if (INPUT.nextLine().trim().equalsIgnoreCase("save")) {
                    System.out.print("Enter the filename: ");
                    try {
                        game.saveBoard(INPUT.nextLine());
                        System.out.println("Game saved!");
                    } catch (IOException e) {
                        System.out.println("Saving failed!");
                    }
                }
            }
        }
    }

    /**
     * Draws a Board for the player to reference and play off of
     * 
     * @param board Board to draw
     */
    public static void drawBoard(Board board) {
        System.out.println(board);
        System.out.println("-".repeat(WIDTH * 2 - 1));
        for (int i = 0; i < WIDTH; i++) {
            System.out.print(i + 1);
            System.out.print(' ');
        }
        System.out.println();
    }

    /**
     * Constants related to the view
     */
    public static final String WELCOME_MSG = "Welcome to Connect 4" + '\n' + "Select either play, load or quit";
    public static final String TAKE_TURN_MSG = "Please take a turn (%s) (1 - %d) or save: ";
}
