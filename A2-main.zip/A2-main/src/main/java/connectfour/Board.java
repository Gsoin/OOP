package connectfour;

import java.io.IOException;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;


import java.util.Arrays;
import java.util.Scanner;

/**
 * Board class behind all of the logic for a Connect 4 game
 * Includes loading and saving from csv files
 * 
 * @Gunteshwar Soin
 */
public class Board {

    /**
     * Constants related to board size
     */
    public static final int WIDTH = 7;
    public static final int HEIGHT = 6;

    /**
     * Constants related to board cells
     */
    public static final char EMPTY = 0;
    public static final char RED = 'R';
    public static final char YELLOW = 'Y';
    

    /**
     * Main structure that represents a board
     */
    private final char[][] cells = new char[WIDTH][HEIGHT];

    /**
     * Tracks the number of chips form either player
     */
    private int redChips = 0;
    private int yellowChips = 0;

    /**
     * Creates a new empty board
     */
    public Board() {
    }

    private char advanceChip() {
        if (redChips == yellowChips) {
            redChips++;
            return RED;
        } else {
            yellowChips++;
            return YELLOW;
        }
    }

    /**
     * Returns the player who's about to take a turn
     * 
     * @return Player who's about to take a turn
     */
    public char getPlayer() {
        return redChips == yellowChips ? RED : YELLOW;
    }

    /**
     * Returns the player who's waiting to take his turn
     * 
     * @return Player who's waiting to take his turn
     */
    public char otherPlayer() {
        return redChips == yellowChips ? YELLOW : RED;
    }

    /**
     * Allows the current player to drop a chip in the specified column
     * 
     * @param column the column to drop the chip at
     * @return The row the chip ended at or -1 if the row is full
     * @throws IllegalArgumentException If the column is out of range
     */
    public int dropChip(int column) {
        if (column < 0 || Board.WIDTH <= column) {
            throw new IllegalArgumentException("Column out of range");
        }

        for (int y = 0; y < Board.HEIGHT; y++) {
            if (cells[column][y] == EMPTY) {
                cells[column][y] = advanceChip();
                return y;
            }
        }
        return -1;
    }

    /**
     * Returns whether the board can house more chips
     * 
     * @return Whether the board can house more chips
     */
    public boolean hasSpace() {
        return redChips + yellowChips < WIDTH * HEIGHT;
    }

    /**
     * Helper method to check if given values are in bounds
     * 
     * @param x X position
     * @param y Y position
     * @return Whether the given position is within the board
     */
    private static boolean inRange(int x, int y) {
        return !(x < 0 || Board.WIDTH <= x || y < 0 || Board.HEIGHT <= y);
    }

    /**
     * Constant for the minimum sequence length for a win condition
     */
    private static final int WIN_LENGTH = 4;

    /**
     * Constants for the checker movement
     */
    private static final int[][] DIRECTIONS = {{1, 0}, {1, 1}, {0, 1}, {-1, 1}};

    /**
     * Method that checks whether the chip at x, y fulfills the winning condition
     * (WIN_LENGTH >= 4)
     * 
     * @see Board#WIN_LENGTH
     * @param x X position of the chip
     * @param y Y position of teh chip
     * @return Whether the chip at x,y fulfills a winning condition
     * @throws IllegalArgumentException If x,y is outside the board
     * @throws IllegalArgumentException If the cell at x,y is empty
     */
    public boolean isWinning(int x, int y) {
        if (!inRange(x, y)) {
            throw new IllegalArgumentException("Position out of range");
        }
        char chip = cells[x][y];
        if (chip == 0) {
            throw new IllegalArgumentException("Not a chip");
        }
        for (int[] direction : DIRECTIONS) {
            int length = 1;
            for (int i = 0; i < 2; i++) {
                int way = i == 0 ? 1 : -1;
                int nx = x + direction[0] * way; 
                int ny = y + direction[1] * way;
                while (inRange(nx, ny) && cells[nx][ny] == chip) {
                    length++;
                    if (length == WIN_LENGTH) {
                        return true;
                    }
                    nx += direction[0] * way;
                    ny += direction[1] * way;
                }
            }
        }
        return false;
    }

    /**
     * Returns the chip at x,y
     * 
     * @param x X position
     * @param y Y position
     * @return Chip at x,y
     * @throws IllegalArgumentException If x,y is outside the board
     */
    public char getChip(int x, int y) {
        if (!inRange(x, y)) {
            throw new IllegalArgumentException("Out of range position");
        }
        return cells[x][y];
    }

    private static final String SEPARATOR = ",";

    /**
     * Helper method for tests to write the board to a sink
     * 
     * @param sink Writer sink
     * @throws IOException If the writer fails writing
     */
    void writeBoardTo(Writer sink) throws IOException {
        for (int y = HEIGHT - 1; 0 <= y; y--) {
            for (int x = 0; x < WIDTH; x++) {
                char chip = cells[x][y];
                if (chip == EMPTY) {
                    chip = '0';
                }
                if (chip == RED) {
                    chip = '1';
                }
                if (chip == YELLOW) {
                    chip = '2';
                }
                sink.write(chip);
                if (x != WIDTH - 1) {
                    sink.write(SEPARATOR);
                }
            }
            if (y != 0) {
                sink.write('\n');
            }
        }
    }

    /**
     * Saves the board to a csv file
     * 
     * @see Board#writeBoardTo(Writer)
     * @param filename File name to save into
     * @throws IOException If the file operation fails
     */
    public void saveBoard(String filename) throws IOException {
        BufferedWriter file = new BufferedWriter(new FileWriter(filename));
        writeBoardTo(file);
        file.close();
    }

    /**
     * Static helper method to rebuild a board from a csv source, for tests
     * 
     * @param source Reader to rebuilt a Board from
     * @return Board rebuilt from the csv source
     * @throws IllegalStateException If the cell doesn't contain a chip
     * @throws IllegalStateException If the cell isn't 0,1,2 (empty, red, yellow)
     * @throws IllegalStateException If there are too many columns
     * @throws IllegalStateException If there are too many rows
     * @throws IllegalStateException If there are too many chips of one color
     */
    static Board readFrom(Reader source) {
        Scanner scanner = new Scanner(source);
        Board board = new Board();
        for (int y = HEIGHT - 1; 0 <= y; y--) {
            Scanner line = new Scanner(scanner.nextLine());
            line.useDelimiter(SEPARATOR);
            for (int x = 0; x < WIDTH; x++) {
                String chipSeq = line.next();
                if (chipSeq.length() != 1) {
                    throw new IllegalStateException("Invalid chip format");
                }
                char chip = chipSeq.charAt(0);

                if (chip == '0') {
                    chip = EMPTY;
                }
                if (chip == '1') {
                    chip = RED;
                }
                if (chip == '2') {
                    chip = YELLOW;
                }
                if (chip != EMPTY && chip != RED && chip != YELLOW) {
                    throw new IllegalStateException("Unknown chip");
                }

                if (chip == RED) {
                    board.redChips++;
                }
                if (chip == YELLOW) {
                    board.yellowChips++;
                }

                board.cells[x][y] = chip;
            }
            if (line.hasNext()) {
                throw new IllegalStateException("Too many columns");
            }
        }
        if (scanner.hasNext()) {
            throw new IllegalStateException("Too many rows");
        }

        int delta = board.redChips - board.yellowChips;
        if (delta != 0 && delta != 1) {
            throw new IllegalStateException("Too much chips of one color");
        }

        return board;
    }
    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return super.hashCode();
    }

    /**
     * Method to make a board from a csv file
     * 
     * @see Board#readFrom(Reader)
     * @param filename File to open and read from
     * @return Board rebuilt from the csv source
     * @throws IOException If the file failed opening
     */
    public static Board loadBoard(String filename) throws IOException {
        BufferedReader file = new BufferedReader(new FileReader(filename));
        Board board = readFrom(file);
        file.close();
        return board;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Board)) {
            return false;
        }

        return Arrays.deepEquals(cells, ((Board) other).cells);
    }

    @Override
    public String toString() {
        StringBuilder string = new StringBuilder();
        for (int y = HEIGHT - 1; 0 <= y; y--) {
            char cell = cells[0][y];
            if (cell == EMPTY) {
                cell = '.';
            }
            string.append(cell);
            for (int x = 1; x < WIDTH; x++) {
                string.append(' ');
                char chip = cells[x][y];
                if (chip == EMPTY) {
                    chip = '.';
                }
                string.append(chip);
            }
            string.append('\n');
        }
        return string.toString();
    }
}
