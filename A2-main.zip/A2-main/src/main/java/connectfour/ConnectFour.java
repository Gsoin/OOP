package connectfour;


/**
 * Connect Four Driver
 * 
 * @Gunteshwar Soin
 */
public class ConnectFour {
    /**
     * Main method that plays out a Connect 4 game as well as handling player
     * controls
     * 
     * @param args Commandline arguments
     */
    public static void main(String[] args) {
        while (true) {
            Board game = TextUI.askStartGame();
            if (game == null) {
                break;
            }

            while (game.hasSpace()) {
                TextUI.drawBoard(game);
                int column = TextUI.askColumnOrSave(game);

                int row = game.dropChip(column);
                if (row < 0) {
                    System.out.println("Full column, choose another one");
                    continue;
                }

                if (game.isWinning(column, row)) {
                    System.out.printf("Congratulations %s, you won\n", game.otherPlayer());
                    break;
                } else if (!game.hasSpace()) {
                    System.out.println("And its a tie :(");
                    break;
                }
            }
        }
    }
}
