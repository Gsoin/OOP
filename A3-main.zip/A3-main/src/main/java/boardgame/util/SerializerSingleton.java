package boardgame.util;

import com.google.gson.Gson;

public final class SerializerSingleton {
    private SerializerSingleton() {
    }

    private static SerializerSingleton instance = new SerializerSingleton();
    private Gson gsonInstance = new Gson();

    public String serialize(Object o) {
        return gsonInstance.toJson(o);
    }

    public <T> T load(String input, Class<T> type) {
        return gsonInstance.fromJson(input, type);
    }

    public static SerializerSingleton getInstance() {
        return instance;
    }
}
