package boardgame.ui;

import boardgame.controller.TicTacToeGame;
import boardgame.model.dto.Move;
import boardgame.model.dto.Player;

import java.util.Scanner;

public class TextUI {
    private TicTacToeGame ticTacToeGame = new TicTacToeGame();

    public TextUI() {
        var scanner = new Scanner(System.in);
        showHelpBanner();
        makeMove("new");
        while (true) {
            System.out.print("#: ");
            makeMove(scanner.nextLine());
        }
    }

    private void showHelpBanner() {
        System.out.println("Directions:");
        System.out.println("exit - exit the game");
        System.out.println("help - show this banner");
        System.out.println("new - reset game-board");
        System.out.println("<number><number> - make move");
    }


    private boolean commands(String s) {
        switch (s) {
            case "exit":
                System.exit(0);
                break;
            case "help":
                showHelpBanner();
                break;
            case "new":
                ticTacToeGame.reset();
                choosePlayer();
                System.out.println(ticTacToeGame.describe());
                System.out.println(ticTacToeGame.getGameStateMessage());
                break;
            default:
                return false;
        }
        return true;

    }

    private void makeMove(String s) {
        if (commands(s)) {
            return;
        }
        try {
            var res = ticTacToeGame.takeTurn(
                    new Move(ticTacToeGame.getCurrentPlayerForThisTurn(),
                            Integer.parseInt(Character.toString(s.charAt(0))),
                            Integer.parseInt(Character.toString(s.charAt(1)))));
            if (!res) {
                if (ticTacToeGame.isDone()) {
                    if (ticTacToeGame.isTie()) {
                        System.out.println("game is already done! with Tie");
                    } else if (ticTacToeGame.hasWinner()) {
                        System.out.println("game is already done! winner: " + ticTacToeGame.getWinnerSummeryIfExist());
                    } else {
                        System.out.println("game is already done! it's full!");
                    }
                } else {
                    System.out.println("tile is already full!");
                }
            }
            System.out.println(ticTacToeGame.describe());
            System.out.println(ticTacToeGame.getGameStateMessage());
        } catch (NumberFormatException e) {
            System.out.println("not a number: " + s);
        } catch (IllegalArgumentException e) {
            System.out.println("not a valid position: " + e.getMessage());
        }
    }

    private void choosePlayer() {
        System.out.print("choose player (X/O): ");
        var s = new Scanner(System.in).nextLine();
        if (s.equals("X")) {
            ticTacToeGame.setPlayerSelectedToPlayAs(Player.PLAYER_X);
        } else if (s.equals("O")) {
            ticTacToeGame.setPlayerSelectedToPlayAs(Player.PLAYER_O);
        } else {
            choosePlayer();
        }
    }

    public static void main(String[] args) {
        new TextUI();
    }


}
