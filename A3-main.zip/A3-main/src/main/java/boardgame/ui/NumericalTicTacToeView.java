package boardgame.ui;

import boardgame.controller.NumericalTicTacToe;
import boardgame.model.dto.LocationTuple;
import boardgame.model.dto.NumericalMove;
import boardgame.model.dto.Player;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Container;

import java.util.Arrays;

public class NumericalTicTacToeView {
    private Container pane;
    private JButton[][] tttboard;
    private JMenuBar menuBar;

    private DriverUi driverUi;


    private NumericalTicTacToe ttt;

    public NumericalTicTacToeView(DriverUi du) {
        this.driverUi = du;
        pane = du.getPane();
        pane.setLayout(new GridLayout(3, 3)); // creates 3x3 layout pane
        ttt = new NumericalTicTacToe();
        tttboard = new JButton[3][3];
        instantiateBoard();
        instantiateBar();
        resetBoard();

    }


    private void instantiateBar() {
        menuBar = new JMenuBar();

        JMenu gameMenu = new JMenu("Game");
        instantiateGameBar(gameMenu);
        menuBar.add(gameMenu);
        driverUi.getMenuBar1().add(menuBar); //Creates Menu Bar
    }

    private void instantiateGameBar(JMenu menu) {
        var directions = new JMenuItem("How To Play?");
        // Button for the game directions
        directions.addActionListener(e -> {
            getDirections(); // see the directions
        });
        var newGame = new JMenuItem("New Game");
        // Button for new game
        newGame.addActionListener(e -> {
            resetBoard(); // new blank board
        });
        var goBack = new JMenuItem("Back");
        goBack.addActionListener(e -> driverUi.goBack());
        var saveThiGame = new JMenuItem("Save This Game");
        saveThiGame.addActionListener(e -> saveThisGameForLater());
        var loadLastGame = new JMenuItem("Load Last Unfinished Game");
        loadLastGame.addActionListener(e -> loadLastGameIfExist());
        menu.add(newGame);
        menu.add(saveThiGame);
        menu.add(loadLastGame);
        menu.add(directions);
        menu.add(goBack);
    }

    private void saveThisGameForLater() {
        driverUi.getAppState().currentPlayer.currentTicTacToe = ttt;
        driverUi.saveState();
    }

    private void loadLastGameIfExist() {
        var lastGame = driverUi.getAppState().currentPlayer.currentNumericalTicTacToe;
        if (lastGame == null) {
            driverUi.showDialog("no last game found!");
            return;
        }
        if (!lastGame.isDone()) {
            ttt = lastGame;
            reDrawBoard();
        }
    }


    private void getDirections() {
        JLabel dMessage = new JLabel("Get 15 in a row! Player 1=x (even)  Player 2=o (odd)", null, JLabel.LEFT);
        dMessage.setFont(new Font("SANS_SERIF", Font.BOLD, 18));
        dMessage.setForeground(Color.black);
        JOptionPane.showMessageDialog(null, dMessage, "DIRECTIONS", JOptionPane.PLAIN_MESSAGE);

    }

    private void reDrawBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tttboard[i][j].setText(ttt.valueAt(j + 1, i + 1));
            }
        }

    }

    private void resetBoard() {
        ttt.reset();
        askToPlayAs();
        reDrawBoard();
    }

    private void askToPlayAs() {
        String input = (String) JOptionPane.showInputDialog(driverUi,
                "Select X if you want to play as X otherwise O (X is Even and O is Odd)",
                "choose your team!", JOptionPane.PLAIN_MESSAGE, null, null, "X");
//        System.out.println(input);
        if (!input.equals("X") && !input.equals("O")) {
            askToPlayAs();
        }
        ttt.setPlayerSelectedToPlayAs(input.equals("X") ? Player.PLAYER_X : Player.PLAYER_O);
    }

    private void instantiateBoard() {
        for (int r = 1; r <= 3; r++) {
            for (int c = 1; c <= 3; c++) {
                final JButton BTN = new JButton();
                BTN.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 120));
                BTN.setOpaque(true); // colored border between squares
                BTN.setBackground(Color.blue);

                tttboard[r - 1][c - 1] = BTN;
                // Button to quit game
                int finalR = r;
                int finalC = c;
                BTN.addActionListener(e -> {
                    if (BTN.getText().isEmpty()) {
                        makeMove(finalR, finalC);
                    }
                });
                pane.add(BTN);
            }
        }
    }

    private void makeMove(int r, int c) {
        if (ttt.isDone()) {
            driverUi.showDialog("This move is illegal because: GAME_ALREADY_ENDED");
            return;
        }
        String availableValues = getAvailableMoveValues();
        String input = (String) JOptionPane.showInputDialog(
                driverUi, "what value you want to put " + availableValues, "choose your team!",
                JOptionPane.PLAIN_MESSAGE, null, null, "?");
        try {
            var selectedNumber = Integer.parseInt(input);
            if (!availableValues.contains(input)) {
                driverUi.showDialog("This move is illegal because: " + "YOU_CANT_USE_THIS_VALUE");
                return;
            }
            if (ttt.takeTurn(
                    new NumericalMove(ttt.getCurrentPlayerForThisTurn(), new LocationTuple(c, r), selectedNumber))) {
                reDrawBoard();
                checkState();
            } else {
                driverUi.showDialog("This move is illegal because: TILE_ALREADY_FULL");
            }
        } catch (NumberFormatException nf) {
            driverUi.showDialog(input + " is not a number");
        }
    }

    private String getAvailableMoveValues() {
        var player = ttt.getCurrentPlayerForThisTurn();

        var avOptions = Arrays.stream(ttt.getAvailableMoveValues())
                .filter(x -> {
                    if (player == Player.PLAYER_X) {
                        return x % 2 == 0;
                    } else {
                        return x % 2 == 1;
                    }
                }).toArray();

        var res = "";
        for (int avOption : avOptions) {
            res = res + "," + avOption;
        }
        return res;
    }


    private void checkState() {

//        System.out.println(ttt.describe());
//        System.out.println(ttt.getGameStateMessage());

        if (!ttt.isDone()) {
            return;
        }

        if (ttt.isTie()) {
            driverUi.showDialog("Game is Ended and Tie is Reached, well played!");
        }

        var winner = ttt.getWinnerSummeryIfExist();
        if (winner != null) {
            driverUi.showDialog("Game is Ended and Win is Reached, " + winner.toString());
        }

        driverUi.getAppState().currentPlayer.currentNumericalTicTacToe = ttt;
        driverUi.getAppState().currentPlayer.addNumericalTicTacToeAsFinished();
        driverUi.saveState();
    }


}
