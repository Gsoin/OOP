package boardgame.ui;

import boardgame.model.AppState;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Container;

import java.io.File;
import java.io.IOException;

public class DriverUi extends JFrame {
    public AppState getAppState() {
        return appState;
    }

    public Container getPane() {
        return pane;
    }


    private final AppState appState;

    private File selectedFile;
    private final Container pane;


    public JMenuBar getMenuBar1() {
        return menuBar;
    }

    private JMenuBar menuBar;

    public DriverUi() {
        super(); // JFrame
        pane = getContentPane();
        setTitle("GameSuit");
        setSize(810, 810);
        setLocationRelativeTo(null);
        setResizable(false); // user can't resize window
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true); // displays GUI
        instantiateBar();
        drawGameChooser();
        chooseFile();
        appState = new AppState();
        try {
            appState.readFrom(selectedFile);
        } catch (IOException e) {
            showDialog("file is not writable " + e.getMessage());
        }
        choosePlayer();
    }

    private void choosePlayer() {
        String input = (String) JOptionPane.showInputDialog(this,
                "choose your name", "choose your team!", JOptionPane.PLAIN_MESSAGE, null, null, "");
        appState.selectPlayer(input);
    }

    private void drawGameChooser() {
        pane.removeAll();
        pane.setLayout(new GridLayout(1, 2)); // creates 3x3 layout pane
        var tttBtn = new JButton();
        pane.add(tttBtn);
        tttBtn.setText("Go To TicTacToe");
        tttBtn.addActionListener(e -> {
            pane.removeAll();
            var loader = new TicTacToeView(this);
            invalidate();
            validate();
            repaint();
        });

        var tttnBtn = new JButton();
        tttnBtn.setText("Go To TicTacToe Numerical");
        tttnBtn.addActionListener(e -> {
            pane.removeAll();
            var loader = new NumericalTicTacToeView(this);
            invalidate();
            validate();
            repaint();
        });
        pane.add(tttnBtn);
    }

    private void instantiateBar() {
        menuBar = new JMenuBar();

        JMenu fileBar = new JMenu("Menu");
        instantiateFileBar(fileBar);
        menuBar.add(fileBar);

        JMenu profileBar = new JMenu("Profile");
        instantiateProfileBar(profileBar);
        menuBar.add(profileBar);


        setJMenuBar(menuBar); //Creates Menu Bar
    }

    private void instantiateProfileBar(JMenu profileBar) {
        var selectSaveLocation = new JMenuItem("TicTacToe Summery");
        selectSaveLocation.addActionListener((e) -> {
            showDialog("Hi, " + appState.currentPlayer.name + "! TicTocToe summery: " + appState.currentPlayer
                    .ticTocToeSummary());
        });

        var changeProfile = new JMenuItem("Change Profile");
        changeProfile.addActionListener(e -> choosePlayer());

        profileBar.add(selectSaveLocation);
        profileBar.add(changeProfile);
    }

    private void instantiateFileBar(JMenu menu) {
        var selectSaveLocation = new JMenuItem("ChooseSaveLocation");
        selectSaveLocation.addActionListener((e) -> {
            chooseFile();
        });
        var quit = new JMenuItem("Quit");
        // Button to quit game
        quit.addActionListener(e -> {
            System.exit(0); //ends game
        });
        menu.add(selectSaveLocation);
        menu.add(quit);
    }

    private void chooseFile() {
        var chooser = new JFileChooser();
        chooser.showSaveDialog(null);
        selectedFile = chooser.getSelectedFile();
        showDialog("now data will be saved in: " + selectedFile.toPath().toAbsolutePath());
        readSavedState();
    }


    private void readSavedState() {
        if (!selectedFile.exists()) {
            try {
                selectedFile.createNewFile();
            } catch (IOException e) {
                showDialog("can't make file here: " + e.getMessage());
            }
        }
    }

    void showDialog(String msg) {
        JLabel winnerMessage = new JLabel(msg, JLabel.LEFT);
        winnerMessage.setFont(new Font("SANS_SERIF", Font.BOLD, 36));
        winnerMessage.setForeground(Color.red);
        JOptionPane.showMessageDialog(null, winnerMessage,
                "WINNER", JOptionPane.PLAIN_MESSAGE);
    }

    public void saveState() {
        try {
            appState.writeTo(selectedFile);
        } catch (IOException e) {
            showDialog("file is not writable " + e.getMessage());
        }
    }

    public void goBack() {
        menuBar.removeAll();
        instantiateBar();
        drawGameChooser();
    }
}
