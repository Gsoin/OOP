package boardgame.model.dto;
//CHECKSTYLE:OFF
// because it's DTO
public class NumericalMove extends Move{
    public int number;
    public NumericalMove(Player p, LocationTuple locationTuple, int number) {
        super(p, locationTuple);
        this.number = number;
    }
}
//CHECKSTYLE:ON