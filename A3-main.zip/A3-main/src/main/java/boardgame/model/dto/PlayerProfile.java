package boardgame.model.dto;

import boardgame.controller.NumericalTicTacToe;
import boardgame.controller.TicTacToeGame;
import com.google.gson.annotations.Expose;

import java.util.HashSet;
import java.util.Objects;

//CHECKSTYLE:OFF
// because it's DTO
public class PlayerProfile {
    @Expose
    public String name;
    @Expose

    HashSet<TicTacToeGame> ticTacToePlayedGames = new HashSet<>();
    @Expose
    public TicTacToeGame currentTicTacToe;
    @Expose
    public NumericalTicTacToe currentNumericalTicTacToe;

    @Expose
    HashSet<NumericalTicTacToe> numericalTicTacToePlayedGames = new HashSet<>();


    public String ticTocToeSummary() {
        int numberOfGamesPlayed = ticTacToePlayedGames.size();
        int numberOfWins = (int) ticTacToePlayedGames.stream()
                .filter((i) -> i.getPlayerSelectedToPlayAs().ordinal() + 1 == i.getWinner())
                .count();

        return "Number Of Wins: " + numberOfWins + " Total Number Of Games: " + numberOfGamesPlayed;

    }

    public String numericalTicTocToeSummary() {
        int numberOfGamesPlayed = numericalTicTacToePlayedGames.size();
        int numberOfWins = (int) numericalTicTacToePlayedGames.stream()
                .filter((i) -> i.getPlayerSelectedToPlayAs().ordinal() + 1 == i.getWinner())
                .count();

        return "Number Of Wins: " + numberOfWins + " Total Number Of Games: " + numberOfGamesPlayed;

    }

    public void addTicTacToeAsFinished() {
        if (currentTicTacToe != null) {
            ticTacToePlayedGames.add(currentTicTacToe);
        }
    }

    public void addNumericalTicTacToeAsFinished() {
        if (currentNumericalTicTacToe != null) {
            numericalTicTacToePlayedGames.add(currentNumericalTicTacToe);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PlayerProfile that = (PlayerProfile) o;
        return Objects.equals(name, that.name)
                &&
                Objects.equals(ticTacToePlayedGames, that.ticTacToePlayedGames)
                &&
                Objects.equals(currentTicTacToe, that.currentTicTacToe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, ticTacToePlayedGames, currentTicTacToe);
    }
}
//CHECKSTYLE:ON