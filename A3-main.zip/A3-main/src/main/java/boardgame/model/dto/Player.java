package boardgame.model.dto;

import boardgame.Saveable;

public enum Player{
    PLAYER_X,
    PLAYER_O;
}
