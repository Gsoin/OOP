package boardgame.model.dto;


public class WinSummery {
    private Player p;
    private WinType w;
    private int number;

    public enum WinType {
        Horizontal,
        Vertical,
        Diagonal
    }


    public WinSummery(Player pp, WinType ww, int num) {
        this.p = pp;
        this.number = num;
        this.w = ww;
    }

    @Override
    public String toString() {
        String msg = String.format("Player: %s, Type: %s, winPosition: ", p, w);
        switch (w) {
            case Diagonal:
                return msg + (number == 1 ? "left-to-right diagonal" : "right-to-left diagonal");
            case Vertical:
                return msg + "Column " + number;
            case Horizontal:
                return msg + "Row " + number;
            default:
                return "Shouldn't Reach!";
        }
    }
}
