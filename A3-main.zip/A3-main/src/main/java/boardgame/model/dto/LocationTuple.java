package boardgame.model.dto;

import boardgame.Saveable;
import boardgame.util.SerializerSingleton;

import java.util.Objects;

/**
 * simple DTO class to hold coordinates
 */
//CHECKSTYLE:OFF
// this is DTO
public class LocationTuple implements Saveable {
    public int x;
    public int y;

    public LocationTuple(int x, int y) {
        if (x > 3 || y > 3 || x < 1 || y < 1)
            throw new IllegalArgumentException("coordinates can be between 1 and 3 inclusive");
        this.x = x;
        this.y = y;
    }

    // package protected only intended to create empty object to load from string
    LocationTuple() {
    }

    @Override
    public String getStringToSave() {
        return SerializerSingleton.getInstance().serialize(this);
    }

    @Override
    public void loadSavedString(String toLoad) {
        LocationTuple item = SerializerSingleton.getInstance().load(toLoad, getClass());
        this.x = item.x;
        this.y = item.y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LocationTuple that = (LocationTuple) o;
        return x == that.x && y == that.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}
//CHECKSTYLE:ON