package boardgame.model.dto;

import boardgame.Saveable;
import boardgame.util.SerializerSingleton;

import java.util.Objects;
//CHECKSTYLE:OFF
// because it's DTO
public class Move implements Saveable {
    public Player p;
    public LocationTuple locationTuple;

    public Move(Player p, LocationTuple locationTuple) {
        this.p = p;
        this.locationTuple = locationTuple;
    }

    public Move(Player p, int x, int y) {
        this.p = p;
        this.locationTuple = new LocationTuple(x, y);
    }

    // package protected only for serialization
    Move() {
    }

    @Override
    public String getStringToSave() {
        return SerializerSingleton.getInstance().serialize(this);
    }

    @Override
    public void loadSavedString(String toLoad) {
        Move item = SerializerSingleton.getInstance().load(toLoad, getClass());
        this.p = item.p;
        this.locationTuple = item.locationTuple;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Move move = (Move) o;
        return p == move.p && Objects.equals(locationTuple, move.locationTuple);
    }

    @Override
    public int hashCode() {
        return Objects.hash(p, locationTuple);
    }
}
//CHECKSTYLE:ON