package boardgame.model;

import boardgame.model.dto.PlayerProfile;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashSet;

//CHECKSTYLE:OFF
// THIS IS DTO
public class AppState {
    @Expose
    HashSet<PlayerProfile> players = new HashSet<>();
    @Expose
    public PlayerProfile currentPlayer;
    Gson gson = new GsonBuilder()
            .excludeFieldsWithoutExposeAnnotation()
            .create();
    public void readFrom(File file) throws IOException {

        var read = gson.fromJson(Files.readString(file.toPath()), AppState.class);
        if (read != null) {
            this.players = read.players;
        }
    }

    public void writeTo(File file) throws IOException {
        Files.writeString(file.toPath(),gson.toJson(this));
    }

    public void selectPlayer(String input) {
        currentPlayer = players.stream().filter(p -> p.name.equals(input)).findFirst().orElseGet(() -> {
            currentPlayer = new PlayerProfile();
            players.add(currentPlayer);
            currentPlayer.name = input;
            return currentPlayer;
        });
    }
}
//CHECKSTYLE:ON
