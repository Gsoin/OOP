package boardgame.controller;

import boardgame.BoardGame;
import boardgame.Grid;
import boardgame.Saveable;
import boardgame.model.dto.Move;
import boardgame.model.dto.Player;
import boardgame.model.dto.WinSummery;
import boardgame.util.SerializerSingleton;
import com.google.gson.annotations.Expose;

import java.util.Objects;

public class TicTacToeGame extends BoardGame implements Saveable {

    @Expose
    private Player playerSelectedToPlayAs;

    public Player getPlayerSelectedToPlayAs() {
        return playerSelectedToPlayAs;
    }

    public void setPlayerSelectedToPlayAs(Player p) {
        this.playerSelectedToPlayAs = p;
    }

    protected String safeGridAccess(int across, int down) {
        var value = getGrid().getValue(across, down);
        if (Objects.equals(value, " ")) {
            return null;
        }
        return value;

    }


    <T extends Saveable> T safeGridAccessMaterialized(int across, int down, Class<T> clazz) {
        String item = safeGridAccess(across, down);
        if (item == null) {
            return null;
        }
        return SerializerSingleton.getInstance().load(item, clazz);
    }

    public TicTacToeGame() {
        super(3, 3);
    }

    @Override
    public boolean takeTurn(int across, int down, String input) {
        if (safeGridAccess(across, down) == null) {
            getGrid().setValue(across, down, input);
            return true;
        }
        return false;
    }

    @Override
    public boolean takeTurn(int across, int down, int input) {
        // we don't use this method
        throw new RuntimeException("Not Implemented, don't use this method");
    }

    public boolean takeTurn(Move move) {
        if (move.p == getCurrentPlayerForThisTurn() && !isDone()) {
            return this.takeTurn(move.locationTuple.x, move.locationTuple.y, move.getStringToSave());
        } else {
            return false;
        }
    }

    public Player getCurrentPlayerForThisTurn() {
        if (getMoveCount() % 2 == 0) {
            return Player.PLAYER_X;
        } else {
            return Player.PLAYER_O;
        }
    }

    public Player getLastTurnPlayer() {
        return getCurrentPlayerForThisTurn() == Player.PLAYER_O ? Player.PLAYER_X : Player.PLAYER_O;
    }

    protected int getMoveCount() {
        var ctr = 0;
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                if (safeGridAccess(i, j) != null) {
                    ctr++;
                }
            }
        }
        return ctr;
    }

    @Override
    public boolean isDone() {
        return hasWinner() || isFull();
    }

    public boolean hasWinner() {
        return checkHorizontal() != -1 || checkVertical() != -1 || checkCross() != -1;
    }

    public boolean isTie() {
        return isFull() && !hasWinner();
    }

    protected boolean isFull() {
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                if (safeGridAccess(i, j) == null) {
                    return false;
                }
            }
        }

        return true;
    }

    protected int checkHorizontal() {
        for (int i = 1; i <= 3; i++) {
            var firstCellMove = safeGridAccessMaterialized(1, i, Move.class);
            if (firstCellMove == null) {
                continue;
            }
            var areAllTheSame = true;
            for (int j = 1; j <= 3; j++) {
                var cell = safeGridAccessMaterialized(j, i, Move.class);
                areAllTheSame &= cell != null && firstCellMove.p == cell.p;
            }
            if (areAllTheSame) {
                return i;
            }
        }
        return -1;
    }

    protected int checkVertical() {
        var atLeastOneColumnIsVerticallyFilled = false;
        for (int i = 1; i <= 3; i++) {
            var firstCellMove = safeGridAccessMaterialized(i, 1, Move.class);
            if (firstCellMove == null) {
                continue;
            }
            var areAllTheSame = true;
            for (int j = 1; j <= 3; j++) {
                var cell = safeGridAccessMaterialized(i, j, Move.class);
                areAllTheSame &= cell != null && firstCellMove.p == cell.p;
            }
            if (areAllTheSame) {
                return i;
            }
        }
        return -1;
    }

    private boolean checkLtr() {
        Move m1 = safeGridAccessMaterialized(1, 1, Move.class);
        var m1b = m1 != null;
        if (m1b) {
            for (int i = 1; i <= 3; i++) {
                var cell = safeGridAccessMaterialized(i, i, Move.class);
                if (cell == null) {
                    m1b = false;
                } else {
                    m1b &= (m1.p == cell.p);
                }
            }
        }
        return m1b;
    }

    private boolean checkRlt() {
        Move m2 = safeGridAccessMaterialized(3, 1, Move.class);
        var m2b = m2 != null;
        if (m2b) {
            for (int i = 1; i <= 3; i++) {
                var cell = safeGridAccessMaterialized(4 - i, i, Move.class);
                if (cell == null) {
                    m2b = false;
                } else {
                    m2b &= (m2.p == cell.p);
                }
            }
        }
        return m2b;
    }

    protected int checkCross() {
        if (checkLtr()) {
            return 1;
        }
        if (checkRlt()) {
            return 2;
        }
        return -1;
    }

    @Override
    public int getWinner() {
        if (!isDone()) {
            return -1;
        }
        if (isFull()) {
            return 0;
        }

        if (playerWon(Player.PLAYER_X) != null) {
            return 1;
        } else {
            return 2;
        }
    }

    public WinSummery getWinnerSummeryIfExist() {
        var t = checkVertical();
        if (t != -1) {
            return new WinSummery(getLastTurnPlayer(), WinSummery.WinType.Vertical, t);
        }

        t = checkHorizontal();
        if (t != -1) {
            return new WinSummery(getLastTurnPlayer(), WinSummery.WinType.Horizontal, t);
        }

        t = checkCross();
        if (t != -1) {
            return new WinSummery(getLastTurnPlayer(), WinSummery.WinType.Diagonal, t);
        }

        return null;
    }

    protected Move playerWon(Player p) {
        if (!hasWinner()) {
            return null;
        }
        int temp = checkHorizontal();
        if (temp != -1) {
            var cell = safeGridAccessMaterialized(1, temp, Move.class);
            if (cell != null && cell.p == p) {
                return cell;
            }
        }
        temp = checkVertical();
        if (temp != -1) {
            var cell = safeGridAccessMaterialized(temp, 1, Move.class);
            if (cell != null && cell.p == p) {
                return cell;
            }
        }
        temp = checkCross();
        if (temp != -1) {
            var cell = safeGridAccessMaterialized(temp, temp, Move.class);
            if (cell != null && cell.p == p) {
                return cell;
            }
        }
        throw new RuntimeException("this branch should not be reached");
    }

    @Override
    public String getGameStateMessage() {
        var sb = new StringBuilder();
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                var cell = safeGridAccessMaterialized(j, i, Move.class);
                sb.append("|\t").append(cell == null ? "" : cell.p == Player.PLAYER_X ? "X" : "O").append("\t|");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public String describe() {
        return String.format(
                "Done: %b, Full: %b, Round: %d, PlayerTurn: %s, horiz: %d, vert: %d, cross: %d",
                isDone(), isFull(), getMoveCount(), getCurrentPlayerForThisTurn().toString(),
                checkHorizontal(),
                checkVertical(),
                checkCross()
        );
    }

    @Override
    public String getStringToSave() {
        return SerializerSingleton.getInstance().serialize(getGrid());
    }

    @Override
    public void loadSavedString(String toLoad) {
        var grid = SerializerSingleton.getInstance().load(toLoad, Grid.class);
        getGrid().emptyGrid();

        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                getGrid().setValue(i, j, grid.getValue(i, j));
            }
        }
    }

    public void reset() {
        super.newGame();
    }

    public String valueAt(int across, int down) {
        var move = safeGridAccessMaterialized(across, down, Move.class);
        if (move == null) {
            return "";
        }
        return move.p.name().replace("PLAYER_", "");
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        TicTacToeGame that = (TicTacToeGame) o;
        var equality = true;
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                equality &= Objects.equals(safeGridAccess(i, j), that.safeGridAccess(i, j));
            }
        }
        return playerSelectedToPlayAs == that.playerSelectedToPlayAs && equality;
    }

    @Override
    public int hashCode() {
        return Objects.hash(playerSelectedToPlayAs);
    }
}
