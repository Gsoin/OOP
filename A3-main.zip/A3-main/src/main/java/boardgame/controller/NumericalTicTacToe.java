package boardgame.controller;


import boardgame.model.dto.Move;
import boardgame.model.dto.NumericalMove;
import boardgame.model.dto.Player;

import java.util.ArrayList;
import java.util.stream.IntStream;

public class NumericalTicTacToe extends TicTacToeGame {


    @Override
    public boolean takeTurn(Move move) {
        throw new RuntimeException("should not be used");
    }

    public boolean takeTurn(NumericalMove numericalMove) {
        if (!numberExistInGrid(numericalMove.number) && playerCanPlayThisNumber(numericalMove)) {
            return super.takeTurn(numericalMove);
        }
        return false;
    }

    private boolean playerCanPlayThisNumber(NumericalMove numericalMove) {
        var player = getCurrentPlayerForThisTurn();
        if (player == Player.PLAYER_X) {
            return numericalMove.number % 2 == 0;
        } else {
            return numericalMove.number % 2 == 1;
        }
    }

    private boolean numberExistInGrid(int number) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                var cell = safeGridAccessMaterialized(i + 1, j + 1, NumericalMove.class);
                if (cell != null && cell.number == number) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected int checkHorizontal() {
        OuterLoop:
        for (int i = 1; i <= 3; i++) {
            var firstCellMove = safeGridAccessMaterialized(1, i, NumericalMove.class);
            if (firstCellMove == null) {
                continue;
            }
            var nums = new ArrayList<NumericalMove>();
            for (int j = 1; j <= 3; j++) {
                var cell = safeGridAccessMaterialized(j, i, NumericalMove.class);
                if (cell == null) {
                    continue OuterLoop;
                }
                nums.add(cell);
            }
            if (nums.stream().mapToInt(nm -> nm.number).sum() == 15) {
                return i;
            }
        }
        return -1;
    }

    @Override
    protected int checkVertical() {
        OuterLoop:
        for (int i = 1; i <= 3; i++) {
            var firstCellMove = safeGridAccessMaterialized(i, 1, NumericalMove.class);
            if (firstCellMove == null) {
                continue;
            }
            var nums = new ArrayList<NumericalMove>();
            for (int j = 1; j <= 3; j++) {
                var cell = safeGridAccessMaterialized(i, j, NumericalMove.class);
                if (cell == null) {
                    continue OuterLoop;
                }
                nums.add(cell);
            }
            if (nums.stream().mapToInt(nm -> nm.number).sum() == 15) {
                return i;
            }
        }
        return -1;
    }

    @Override
    protected int checkCross() {
        NumericalMove m1 = safeGridAccessMaterialized(1, 1, NumericalMove.class);
        NumericalMove m2 = safeGridAccessMaterialized(2, 2, NumericalMove.class);
        NumericalMove m3 = safeGridAccessMaterialized(3, 3, NumericalMove.class);

        if (m1 != null && m2 != null && m3 != null && m1.number + m2.number + m3.number == 15) {
            return 1;
        }

        m1 = safeGridAccessMaterialized(3, 1, NumericalMove.class);
        m2 = safeGridAccessMaterialized(2, 2, NumericalMove.class);
        m3 = safeGridAccessMaterialized(1, 3, NumericalMove.class);

        if (m1 != null && m2 != null && m3 != null && m1.number + m2.number + m3.number == 15) {
            return 2;
        }

        return -1;
    }

    @Override
    public String getGameStateMessage() {
        var sb = new StringBuilder();
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                var cell = safeGridAccessMaterialized(j, i, NumericalMove.class);
                sb.append("|\t")
                        .append(
                                cell == null
                                        ?
                                        ""
                                        :
                                        (cell.p == Player.PLAYER_X ? "X_" : "O_") + cell.number).append("\t|");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    @Override
    public String valueAt(int across, int down) {
        var val = safeGridAccessMaterialized(across, down, NumericalMove.class);
        if (val == null) {
            return "";
        }
        return (val.p == Player.PLAYER_X ? "X" : "O") + val.number;
    }

    public int[] getAvailableMoveValues() {
        return IntStream.range(0, 10)
                .filter(n -> !numberExistInGrid(n))
                .toArray();

    }
}
