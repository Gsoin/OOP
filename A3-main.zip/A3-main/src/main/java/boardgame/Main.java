package boardgame;

import boardgame.ui.DriverUi;

import javax.swing.SwingUtilities;


public class Main {
    public static void main(String[] args) {
        // play the game
        SwingUtilities.invokeLater(DriverUi::new);

    }
}
