import boardgame.model.dto.LocationTuple;
import boardgame.model.dto.NumericalMove;
import boardgame.controller.NumericalTicTacToe;
import boardgame.model.dto.Player;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

@Ignore
public class DifferentNumericalTicTacToeGamesTest {
    @Test
    public void horizontalGameTest(){

        var nttt = new NumericalTicTacToe();
        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(1,1),4));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_O,new LocationTuple(1,2),3));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(2,1),5));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_O,new LocationTuple(2,2),2));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(3,1),6));

        System.out.println(nttt.describe());
        System.out.println(nttt.getGameStateMessage());

        Assert.assertTrue(nttt.isDone());
        Assert.assertEquals(nttt.getWinner(), 1);
    }

    @Test
    public void verticalGameTest(){

        var nttt = new NumericalTicTacToe();
        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(1,1),4));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_O,new LocationTuple(2,1),3));

        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(1,2),5));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_O,new LocationTuple(2,2),2));

        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(1,3),6));

        System.out.println(nttt.describe());
        System.out.println(nttt.getGameStateMessage());

        Assert.assertTrue(nttt.isDone());
        Assert.assertEquals(nttt.getWinner(), 1);
    }

    @Test
    public void crossGameTest(){

        var nttt = new NumericalTicTacToe();
        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(1,1),4));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_O,new LocationTuple(2,1),3));

        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(2,2),5));
        nttt.takeTurn(new NumericalMove(Player.PLAYER_O,new LocationTuple(1,2),2));

        nttt.takeTurn(new NumericalMove(Player.PLAYER_X,new LocationTuple(3,3),6));

        System.out.println(nttt.describe());
        System.out.println(nttt.getGameStateMessage());

        Assert.assertTrue(nttt.isDone());
        Assert.assertEquals(nttt.getWinner(), 1);
    }
}
