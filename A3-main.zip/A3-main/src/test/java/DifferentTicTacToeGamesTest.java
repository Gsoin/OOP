import boardgame.model.dto.Move;
import boardgame.model.dto.Player;
import boardgame.controller.TicTacToeGame;
import org.junit.Assert;
import org.junit.Test;

public class DifferentTicTacToeGamesTest {
    @Test
    public void crossLineWins(){
        var ttt = new TicTacToeGame();
        ttt.takeTurn(new Move(Player.PLAYER_X, 1, 1));
        ttt.takeTurn(new Move(Player.PLAYER_O, 1, 2));

        ttt.takeTurn(new Move(Player.PLAYER_X, 2, 2));
        ttt.takeTurn(new Move(Player.PLAYER_O, 2, 3));

        ttt.takeTurn(new Move(Player.PLAYER_X, 3, 3));

        Assert.assertTrue(ttt.isDone());
        Assert.assertEquals(ttt.getWinner(),1);
        System.out.println(ttt.describe());

    }
    @Test
    public void crossLineWinsInverse(){
        var ttt = new TicTacToeGame();
        ttt.takeTurn(new Move(Player.PLAYER_X, 3, 1));
        ttt.takeTurn(new Move(Player.PLAYER_O, 1, 1));

        ttt.takeTurn(new Move(Player.PLAYER_X, 2, 2));
        ttt.takeTurn(new Move(Player.PLAYER_O, 2, 3));

        ttt.takeTurn(new Move(Player.PLAYER_X, 1, 3));

        System.out.println(ttt.describe());
        System.out.println(ttt.getGameStateMessage());
        Assert.assertTrue(ttt.isDone());
        Assert.assertEquals(ttt.getWinner(),1);

    }

    @Test
    public void horizontalWins(){
        var ttt = new TicTacToeGame();
        ttt.takeTurn(new Move(Player.PLAYER_X, 1, 1));
        ttt.takeTurn(new Move(Player.PLAYER_O, 2, 2));
        ttt.takeTurn(new Move(Player.PLAYER_X, 2, 1));
        ttt.takeTurn(new Move(Player.PLAYER_O, 3, 3));
        ttt.takeTurn(new Move(Player.PLAYER_X, 3, 1));

        Assert.assertTrue(ttt.isDone());
        Assert.assertEquals(ttt.getWinner(),1);

        System.out.println(ttt.describe());
        System.out.println(ttt.getGameStateMessage());

    }
}
