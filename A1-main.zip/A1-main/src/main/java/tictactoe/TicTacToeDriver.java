package tictactoe;

import java.util.Scanner;

//this is the driver for the TicTacToeGame, We encapsulate parts of the code and use this to run the whole program.
public class TicTacToeDriver {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        TicTacToeGame game = new TicTacToeGame();

        game.printBoard();
        // Shorter and simple player picker using a ternary statement
        while (game.getTurn() < game.MAX_TURNS) {
            char currentPlayer = game.getPlayer();
            System.out.print("Pick a position for " + currentPlayer + ": ");// asking for next position input from the
                                                                            // next player
            int pos = input.nextInt() - 1;
            if (!game.takeTurn(pos)) {// if out of field/taken
                System.out.println("Please pick a valid cell");
                continue;
            }

            game.printBoard();
            char winner = game.checkWinner();
            if (winner != 0) {
                System.out.println(winner + " has won");// player win
                return;// return from the main method, System.exit is abrupt
            }
        }

        System.out.println("It's a tie");// tie
    }
}