package tictactoe;

/*This class is for the TicTacToeGame itself, 
using private variables and classes, 
this game takes two players sharing one computer. 
We use X and O to display users and let them pick 
a position on the board till there is a win/loss or tie*/
public class TicTacToeGame {

    private static final int W = 3;
    private static final int H = 3;
    public static final int MAX_TURNS = W * H;

    // Better, self-explanatory varible names
    private int turns = 0;
    private final char[][] board = new char[W][H];

    public TicTacToeGame() {
    };

    // useful getters that can be easily called from the driver
    public char getPlayer() {
        if (turns % 2 == 0) {
            return 'X';
        } else {
            return 'O';
        }
    }

    public int getTurn() {
        return turns;
    }

    public boolean takeTurn(int pos) {
        if (pos < 0 || MAX_TURNS <= pos) {
            return false;
        }
        if (board[pos % W][pos / H] != 0) {

            return false;
        }
        board[pos % W][pos / H] = getPlayer();
        turns++;
        return true;
    }

    public char checkWinner() {
        for (int x = 0; x < W; x++) {
            if (tripleEquals(board[x][0], board[x][1], board[x][2])) {
                return board[x][0];
            }
        }
        for (int y = 0; y < H; y++) {
            if (tripleEquals(board[0][y], board[1][y], board[2][y])) {
                return board[0][y];
            }
        }

        if (tripleEquals(board[0][0], board[1][1], board[2][2])) {
            return board[0][0];
        }
        if (tripleEquals(board[0][2], board[1][1], board[2][0])) {
            return board[0][2];
        }

        return 0;
    }

    private static boolean tripleEquals(char a, char b, char c) {
        return a == b && b == c;
    }

    public void printBoard() {
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                char cell = board[x][y];

                if (cell == 0) {
                    System.out.print(y * W + x + 1);
                } else {
                    System.out.print(cell);
                }

                if (x != 3 - 1) {
                    System.out.print('|');
                }
            }
            if (y != 3 - 1) {
                System.out.print("\n-+-+-\n");
            }
        }
        System.out.println('\n');
    }
}
